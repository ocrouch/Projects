//import of package
import java.lang.reflect.Array;
import java.util.ArrayList;
public class BookStore {
    //the message has been provided for you - do not change this
    private final String message = "The urgent orders are piling up .... time to ship quicker";
    //create the invoices ArrayList<>
    private ArrayList <Invoice> invoices;
    //complete the constructor
    public BookStore()
    {
        invoices = new ArrayList<>();
    }
    //getter() for invoices list
    public ArrayList getInvoices()
    {
        return invoices;
    }
    //search for an order
    public Invoice searchOrder(String invoiceNbr)
    {
        Invoice returnInvoice = null;
        for (int x = 0; x < invoices.size(); x++)
        {
            if (invoices.get(x).getInvoiceNbr().equals(invoiceNbr))
            {
                returnInvoice = invoices.get(x);
                break;
            }
        }
    return returnInvoice;
    }
    //piling up of orders
    public String pilingUpOfOrders()
    {
        String orders = null;
        if (Shipping.countUrgent > 5)
        {
            System.out.println(message);
            orders = message;
        }
        else if (Shipping.countUrgent < 5)
        {
            System.out.println();
        }
        return orders;
    }
}
