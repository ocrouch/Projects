import java.time.LocalDate;
import java.util.ArrayList;

public class BookStoreMain {
    public static void main(String[] args) {
        ArrayList <Invoice> invoices = new ArrayList<>();
        //create a bookStore object and instantiate
        BookStore bookStore = new BookStore();
        //create a customer who can then buy books
        Customer customer1 = new Customer("Jane Words", "+4472394586971",
                "wordsj@gmail.com");
        //customer1 places an order to purchase a book
        Stock book1 = new Stock("Death in the afternoon", "Hemingway E.",
                15.45);
        //placing the order ****
        Order order1 = new Order(customer1, book1);
        //determine the shipping date
        LocalDate shipDate1 = LocalDate.of(2022, 12, 25);
        //calculate the shipping cost to send the order
        Shipping shipOrder1 = new Shipping(order1, shipDate1);
        shipOrder1.calcShipCost(true);
        //create an invoice ****
        Invoice invoice1 = new Invoice("DIT001", book1, shipOrder1);
        invoice1.invoice();
        //add the invoices to a list so that we can search for an invoice ****
        invoices.add(invoice1);
        //a repeat with another customer, order, etc...
        Customer customer2 = new Customer("Safwa Woods", "+447981234582", "woodss@gmail.com");
        Stock book2 = new Stock("Lord of the rings","Tolkien J.R.R.", 12.95);
        Order order2 = new Order(customer2, book2);
        //determine the shipping date
        LocalDate shipDate2 = LocalDate.of(2022, 12, 25);
        //calculate the shipping cost to send the order
        Shipping shipOrder2 = new Shipping(order2, shipDate2);
        shipOrder2.calcShipCost(true);
        //create an invoice
        Invoice invoice2 = new Invoice("LOT111", book2, shipOrder2);
        invoice2.invoice();
        //add the invoices to a list so that we can search for an invoice
        invoices.add(invoice2);
        //search for order
        bookStore.pilingUpOfOrders();
        Invoice foundInvoice = bookStore.searchOrder(invoice1.getInvoiceNbr());
    }
}

