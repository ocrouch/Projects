import java.util.ArrayList;

public class Calculator {
    private int operand1;
    private int operand2;
    private char operator;


    private String expression;

    public void setExpression(String expression) {
        this.expression = expression;
    }

    public Calculator() {

    }

    public int getOperand1() {
        return operand1;
    }

    public int getOperand2() {
        return operand2;
    }

    public char getOperator() {
        return operator;
    }

    public boolean verify() {
        boolean valid = false;
        String[] xprsn;
        xprsn = expression.split(" ");
        if (xprsn.length == 3) {
            this.operand1 = Integer.parseInt(xprsn[0]);
            String tempOp = xprsn[1];
            this.operand2 = Integer.parseInt(xprsn[2]);
            this.operator = tempOp.charAt(0);
            if (operator == '/' || operator == '-' || operator == '+' || operator == '*') {
                valid = operator != '/' || operand2 != 0;
            }
        }
        return valid;
    }


// if statements for each operator
    public int evaluate()
    {
        int sum = 0;
        if (operator == '+')
            sum = operand1 + operand2;
        if (operator == '-')
            sum = operand1 - operand2;
        if (operator == '/')
            sum = operand1 / operand2;
        if (operator == '*')
            sum = operand1 * operand2;

        return sum;
    }
}
